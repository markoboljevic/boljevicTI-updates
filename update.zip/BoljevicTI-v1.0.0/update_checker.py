import requests, zipfile, io, os

# Linkovi ka tvojoj GitHub verziji i zip update fajlu
GITHUB_VERSION_URL = "https://raw.githubusercontent.com/markoboljevic/boljevicTI-updates/main/version.txt"
GITHUB_UPDATE_ZIP = "https://github.com/markoboljevic/boljevicTI-updates/raw/main/update.zip"

# Lokalni fajl gde aplikacija čuva svoju verziju
LOCAL_VERSION_FILE = "version.txt"

def get_local_version():
    if not os.path.exists(LOCAL_VERSION_FILE):
        return "0.0.0"
    with open(LOCAL_VERSION_FILE, "r") as f:
        return f.read().strip()

def get_online_version():
    try:
        response = requests.get(GITHUB_VERSION_URL)
        if response.status_code == 200:
            return response.text.strip()
    except Exception as e:
        print(f"⚠️ Greška pri proveri verzije: {e}")
    return None

def update_app():
    print("🔁 Skidanje update-a...")
    try:
        response = requests.get(GITHUB_UPDATE_ZIP)
        if response.status_code == 200:
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
                zip_ref.extractall(os.getcwd())
            print("✅ Ažuriranje završeno.")
            return True
        else:
            print("❌ Neuspelo skidanje update-a.")
    except Exception as e:
        print(f"⚠️ Greška pri skidanje update-a: {e}")
    return False

def check_for_updates():
    local_version = get_local_version()
    online_version = get_online_version()

    if not online_version:
        print("⚠️ Ne mogu da proverim verziju.")
        return

    print(f"📦 Lokalna verzija: {local_version}")
    print(f"🌐 Online verzija: {online_version}")

    if local_version != online_version:
        print("🚀 Dostupan je novi update!")
        if update_app():
            with open(LOCAL_VERSION_FILE, "w") as f:
                f.write(online_version)
            print("✅ Update uspešan! 🔁 Restartuj aplikaciju.")
        else:
            print("❌ Update nije uspeo.")
    else:
        print("✅ Već koristiš najnoviju verziju.")

# Pokreće se samo ako pokreneš fajl direktno
if __name__ == "__main__":
    check_for_updates()
