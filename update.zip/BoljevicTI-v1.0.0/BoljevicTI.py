import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import openai

# Unesi tvoj OpenAI ključ ovde
openai.api_key = "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"

# Glavni prozor
root = tk.Tk()
root.title("BoljevicTI")
root.geometry("1000x700")
root.resizable(False, False)

# Postavljanje pozadinske slike
try:
    slika_pozadina = Image.open("e46csl.jpg")
    slika_pozadina = slika_pozadina.resize((1000, 700), Image.Resampling.LANCZOS)
    slika_pozadina = ImageTk.PhotoImage(slika_pozadina)

    labela_pozadina = tk.Label(root, image=slika_pozadina)
    labela_pozadina.place(x=0, y=0, relwidth=1, relheight=1)
except Exception as e:
    messagebox.showerror("Greška", f"Nije moguće učitati pozadinsku sliku: {e}")

# Naslov aplikacije
naslov = tk.Label(root, text="BoljevicTI - Tehnička baza vozila", font=("Arial", 24, "bold"), bg="#222", fg="white")
naslov.pack(pady=20)

# Polja za unos
frame_pretraga = tk.Frame(root, bg="#333")
frame_pretraga.pack(pady=10)

tk.Label(frame_pretraga, text="Marka:", bg="#333", fg="white").grid(row=0, column=0, padx=5)
unos_marka = tk.Entry(frame_pretraga)
unos_marka.grid(row=0, column=1, padx=5)

tk.Label(frame_pretraga, text="Model:", bg="#333", fg="white").grid(row=0, column=2, padx=5)
unos_model = tk.Entry(frame_pretraga)
unos_model.grid(row=0, column=3, padx=5)

tk.Label(frame_pretraga, text="Godina:", bg="#333", fg="white").grid(row=0, column=4, padx=5)
unos_godina = tk.Entry(frame_pretraga)
unos_godina.grid(row=0, column=5, padx=5)

# Prikaz odgovora
prikaz_odgovora = tk.Text(root, height=15, width=100, wrap=tk.WORD, bg="#f0f0f0")
prikaz_odgovora.pack(pady=10)
prikaz_odgovora.config(state=tk.DISABLED)

# Funkcija za slanje pitanja GPT-u
def posalji_gpt(prompt):
    try:
        client = openai.OpenAI()
        odgovor = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Ti si pomoćnik za aplikaciju BoljevicTI."},
                {"role": "user", "content": prompt}
            ]
        )
        poruka = odgovor.choices[0].message.content
        prikaz_odgovora.config(state=tk.NORMAL)
        prikaz_odgovora.delete(1.0, tk.END)
        prikaz_odgovora.insert(tk.END, poruka)
        prikaz_odgovora.config(state=tk.DISABLED)
    except Exception as e:
        messagebox.showerror("Greška", str(e))

# Funkcija za pretragu
def pretrazi():
    marka = unos_marka.get()
    model = unos_model.get()
    godina = unos_godina.get()
    if not marka or not model or not godina:
        messagebox.showwarning("Upozorenje", "Molimo popunite sva polja.")
        return
    prompt = f"Prikaži tehničke informacije za vozilo {marka} {model} iz {godina}. Obuhvati kodove grešaka, intervale servisa, tehničke specifikacije i dijagrame ako je moguće."
    posalji_gpt(prompt)

# Dugme
btn_pretrazi = tk.Button(root, text="Pretraži vozilo", command=pretrazi, bg="#007acc", fg="white", font=("Arial", 12, "bold"))
btn_pretrazi.pack(pady=10)

# Pokretanje GUI
root.mainloop()
